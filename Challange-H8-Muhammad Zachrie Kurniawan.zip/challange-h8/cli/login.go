package cli

import (
	"bufio"
	"challange-h8/config"
	"challange-h8/entity"
	"challange-h8/helpers"
	"fmt"
	"os"
)

func Login() {
	helpers.ClearScreen()

	consoleReader := bufio.NewReader(os.Stdin)
	var username string
	var password string
	fmt.Println("---------- Login ----------")
	fmt.Println("Masukkan Username Anda")
	username, _ = consoleReader.ReadString('\n')
	fmt.Println("Masukkan Password Anda")
	password, _ = consoleReader.ReadString('\n')

	var user entity.User
	err := config.DB.Where("Username = ?", username).First(&user).Error
	if err != nil {
		entity.PrintErrorLogin()
		Login()
	}
	pwdMatch := entity.ComparePassword(user.Password, []byte(password))
	if !pwdMatch {
		entity.PrintErrorLogin()
		Login()
	}

	user.PrintWelcome()

	var input string
	fmt.Println("Tekan (key apapun) untuk kembali ke halaman utama")
	fmt.Println("Tekan (q) untuk keluar dari aplikasi")

	_, err = fmt.Scanln(&input)
	if err != nil {
		MainMenu()
	}

	switch input {
	case "q":
		fmt.Println("Terima kasih telah menggunakan aplikasi ini")
		os.Exit(1)
	default:
		MainMenu()
	}
}
