package cli

import (
	"challange-h8/helpers"
	"fmt"
	"os"
)

func MainMenu() {
	helpers.ClearScreen()
	fmt.Println("--- Main Menu ---")

	var input string
	fmt.Println("1. Register User")
	fmt.Println("2. Login")
	fmt.Println("Tekan (q) untuk keluar dari aplikasi")

	_, err := fmt.Scanln(&input)
	if err != nil {
		fmt.Println(err.Error())
	}

	switch input {
	case "1":
		Register()
	case "2":
		Login()
	case "q":
		fmt.Println("Terima kasih telah menggunakan aplikasi ini")
		os.Exit(1)
	default:
		MainMenu()
	}
}
