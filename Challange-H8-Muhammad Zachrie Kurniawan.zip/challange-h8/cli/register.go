package cli

import (
	"bufio"
	"challange-h8/config"
	"challange-h8/entity"
	"challange-h8/helpers"
	"fmt"
	"os"
)

func Register() {
	helpers.ClearScreen()

	consoleReader := bufio.NewReader(os.Stdin)
	var username string
	var password string
	fmt.Println("---------- Register User ----------")
	fmt.Println("Masukkan Username Anda")
	username, _ = consoleReader.ReadString('\n')
	fmt.Println("Masukkan Password Anda")
	password, _ = consoleReader.ReadString('\n')

	user := entity.User{
		Username: username,
		Password: entity.HashPassword([]byte(password)),
	}

	err := config.DB.Create(&user).Error
	if err != nil {
		ErrorHandler(err.Error())
		return
	}

	fmt.Println("User berhasil terdaftar")

	var input string
	fmt.Println("Tekan (key apapun) untuk kembali ke halaman utama")
	fmt.Println("Tekan (q) untuk keluar dari aplikasi")

	_, err = fmt.Scanln(&input)
	if err != nil {
		MainMenu()
	}

	switch input {
	case "q":
		fmt.Println("Terima kasih telah menggunakan aplikasi ini")
		os.Exit(1)
	default:
		MainMenu()
	}
}
