package main

import (
	"challange-h8/cli"
	"challange-h8/config"
)

func main() {
	config.DBConnect()
	cli.MainMenu()
}
