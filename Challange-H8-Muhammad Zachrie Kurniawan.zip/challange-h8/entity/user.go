package entity

import (
	"fmt"
	"time"

	"golang.org/x/crypto/bcrypt"
)

type User struct {
	ID       uint
	Username string
	Password string
}

func (user *User) PrintWelcome() {
	fmt.Println("Selamat datang ", user.Username)
}

func PrintErrorLogin() {
	fmt.Println("Username atau Password Anda Salah")
	fmt.Println("Silahkan Login Kembali")
	ticker := time.NewTicker(time.Second * 1)
	i := 3
	for range ticker.C {
		if i == 0 {
			ticker.Stop()
			return
		}
		fmt.Println("Kembali ke Halaman Login dalam Waktu ", i, " Detik")
		i--
	}
	time.Sleep(3 * time.Second)
}

func HashPassword(pwd []byte) string {
	hash, err := bcrypt.GenerateFromPassword(pwd, bcrypt.MinCost)
	if err != nil {
		fmt.Println(err.Error())
	}
	return string(hash)
}

func ComparePassword(hashedPwd string, plainPwd []byte) bool {
	byteHash := []byte(hashedPwd)
	err := bcrypt.CompareHashAndPassword(byteHash, plainPwd)
	if err != nil {
		fmt.Println(err.Error())
		return false
	}
	return true
}
